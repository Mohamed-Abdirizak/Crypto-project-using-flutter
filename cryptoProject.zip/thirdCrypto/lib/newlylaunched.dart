import 'package:flutter/material.dart';

class NewLanuched extends StatelessWidget {
  final image;
  final String coinName;
  final String coinShort;
  final String coinPrice;
  final String coinUp;
  final upOrDownGreenOrRedFontColor;
  final upOrDownIcon;
  final colorsOfUpOrDownIconColor;

  const NewLanuched(
      {super.key,
      required this.image,
      required this.coinName,
      required this.coinShort,
      required this.coinPrice,
      required this.coinUp,
      required this.upOrDownGreenOrRedFontColor,
      required this.upOrDownIcon,
      required this.colorsOfUpOrDownIconColor});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(10),
      decoration: BoxDecoration(
          color: Colors.grey[400], borderRadius: BorderRadius.circular(12)),
      margin: EdgeInsets.all(20),
      child: Row(
        ///start kan waaa rowga guud ee ay ku dhex jiraan xogta dhan..
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            /// start: rowgaan wuxu qeeb gooni ah kadhigaa kaliya, image iyo biton iyo btc. qeeb isla socoto oo kadhigaa.
            children: [
              Image.asset(
                image,
                height: 50,
                width: 50,
              ),
              SizedBox(
                width: 10,
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    this.coinName,
                    style: TextStyle(fontSize: 25, color: Colors.black),
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  Text(
                    this.coinShort,
                    style: TextStyle(fontSize: 25, color: Colors.black),
                  ),
                ],
              ),
            ],
          ), //// end / rowgaan wuxu qeeb gooni ah kadhigaa kaliya, image iyo biton iyo btc. qeeb isla socoto oo kadhigaa.

          Column(
            children: [
              Text(
                "\$" + this.coinPrice + " billion",
                style: TextStyle(fontSize: 25, color: Colors.black),
              ),
              SizedBox(
                height: 10,
              ),
              Container(
                child: Row(
                  children: [
                    Icon(
                      this.upOrDownIcon,
                      color: colorsOfUpOrDownIconColor,
                      size: 40,
                    ),
                    Text(
                      this.coinUp + "%",
                      style: TextStyle(
                          fontSize: 25,
                          color: upOrDownGreenOrRedFontColor,
                          fontWeight: FontWeight.bold),
                    ),
                  ],
                ),
              ),
            ],
          )
        ],
      ),
    );
  }
}
