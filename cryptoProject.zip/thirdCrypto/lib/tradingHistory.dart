import 'package:flutter/material.dart';

class TradinHistory extends StatelessWidget {
  final buyOrSellIcon;
  final buyOrSellBgColor;
  final String buyOrSellText;
  final String date;
  final String buyPlusOrMinus;
  final colorBlueOrRed;
  // final String coinUp;
  // final upOrDownGreenOrRedFontColor;
  // final upOrDownIcon;
  // final colorsOfUpOrDownIconColor;

  const TradinHistory(
      {super.key,
      required this.buyOrSellIcon,
      required this.buyOrSellBgColor,
      required this.buyOrSellText,
      required this.date,
      required this.buyPlusOrMinus,
      // required
      // required this.coinUp,
      // required this.upOrDownGreenOrRedFontColor,
      // required this.upOrDownIcon,
      required this.colorBlueOrRed});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(10),
      decoration: BoxDecoration(
          color: Colors.grey[300], borderRadius: BorderRadius.circular(12)),
      // margin: EdgeInsets.all(20),
      child: Row(
        ///start kan waaa rowga guud ee ay ku dhex jiraan xogta dhan..
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            /// start: rowgaan wuxu qeeb gooni ah kadhigaa kaliya, image iyo biton iyo btc. qeeb isla socoto oo kadhigaa.
            children: [
              Container(
                padding: EdgeInsets.all(10),
                decoration: BoxDecoration(
                    color: buyOrSellBgColor,
                    borderRadius: BorderRadius.circular(20)),
                child: Image.asset(
                  buyOrSellIcon,
                  height: 50,
                  width: 50,
                  color: Colors.white,
                ),
              ),
              SizedBox(
                width: 10,
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    this.buyOrSellText,
                    style: TextStyle(
                        fontSize: 25,
                        color: Colors.black,
                        fontWeight: FontWeight.bold),
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  Text(
                    this.date,
                    style: TextStyle(fontSize: 20, color: Colors.black),
                  ),
                ],
              ),
            ],
          ), //// end / rowgaan wuxu qeeb gooni ah kadhigaa kaliya, image iyo biton iyo btc. qeeb isla socoto oo kadhigaa.

          Column(
            children: [
              Text(
                "+" + this.buyPlusOrMinus + "%BTC",
                style: TextStyle(fontSize: 25, color: this.colorBlueOrRed),
              ),
              SizedBox(
                height: 10,
              ),
            ],
          )
        ],
      ),
    );
  }
}
