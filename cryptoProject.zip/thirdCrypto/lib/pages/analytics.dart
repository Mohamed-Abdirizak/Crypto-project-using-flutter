import 'package:flutter/material.dart';
import 'package:thirdcrypto/pages/home.dart';
import 'package:thirdcrypto/pages/allCoinsPage.dart';
import 'package:thirdcrypto/tradingHistory.dart';

class AnalyticWiddget extends StatelessWidget {
  const AnalyticWiddget({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // backgroundColor: Colors.orange,
      bottomNavigationBar: BottomNavigationBar(items: [
        BottomNavigationBarItem(
            icon: GestureDetector(
              onTap: () => Navigator.push(
                  context, MaterialPageRoute(builder: (context) => Home())),
              child: Icon(
                Icons.home,
                color: Colors.black,
              ),
            ),
            label: ""),
        BottomNavigationBarItem(
            icon: GestureDetector(
              onTap: () => Navigator.push(context,
                  MaterialPageRoute(builder: (context) => AnalyticWiddget())),
              child: Icon(
                Icons.analytics,
                color: Colors.blue,
              ),
            ),
            label: ""),
        BottomNavigationBarItem(
            icon: GestureDetector(
                onTap: () => Navigator.push(context,
                    MaterialPageRoute(builder: (context) => AllCoins())),
                child: Icon(Icons.account_balance_wallet_rounded)),
            label: ""),
        // BottomNavigationBarItem(icon: Icon(Icons.settings_bluetooth), label: "")
      ]),
      body: SafeArea(
        child: Container(
          decoration: BoxDecoration(
              gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [Color(0xFF3ac3cb), Color(0xFFf85187)])),
          // margin: EdgeInsets.all(20),
          child: Container(
            margin: EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    Image.asset(
                      "lib/images/man.png",
                      height: 70,
                      width: 80,
                    ),
                  ],
                ),
                Row(
                  children: [
                    Image.asset(
                      "lib/images/bitcoin.png",
                      height: 50,
                      width: 50,
                    ),
                    Container(
                      margin: EdgeInsets.all(10),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "Bitcoin Price",
                            style: TextStyle(fontSize: 30),
                          ),
                          SizedBox(
                            height: 10,
                          ),
                          Text(
                            "\$60,000",
                            style: TextStyle(
                                fontSize: 30, fontWeight: FontWeight.bold),
                          ),
                          SizedBox(
                            height: 10,
                          ),
                          Row(
                            children: [
                              Text(
                                "\$60,000",
                                style: TextStyle(
                                    fontSize: 30,
                                    color: Colors.green,
                                    fontWeight: FontWeight.bold),
                              ),
                              SizedBox(
                                width: 10,
                              ),
                              Container(
                                padding: EdgeInsets.only(
                                    top: 10, right: 10, bottom: 10),
                                decoration: BoxDecoration(
                                    color: Colors.grey[300],
                                    borderRadius: BorderRadius.circular(12)),
                                child: Row(
                                  children: [
                                    Icon(Icons.arrow_drop_up),
                                    Text(
                                      "+10%",
                                      style: TextStyle(fontSize: 20),
                                    )
                                  ],
                                ),
                              ),
                            ],
                          )
                        ],
                      ),
                    ),
                  ],
                ),
                Row(
                  children: [
                    Container(
                      margin: EdgeInsets.only(bottom: 10),
                      child: Image.asset(
                        "lib/images/area-chart.png",
                        fit: BoxFit.cover,
                        height: 300,
                        width: 510,
                      ),
                    ),
                    // Container(
                    //   margin: EdgeInsets.only(
                    //     bottom: 20,
                    //     left: 5,
                    //   ),
                    // child: Column(
                    //   children: [
                    //     Text(
                    //       "100",
                    //       style: TextStyle(
                    //           fontSize: 20, fontWeight: FontWeight.bold),
                    //     ),
                    //     SizedBox(
                    //       height: 20,
                    //     ),
                    //     Text(
                    //       "90",
                    //       style: TextStyle(
                    //           fontSize: 20, fontWeight: FontWeight.bold),
                    //     ),
                    //     SizedBox(
                    //       height: 20,
                    //     ),
                    //     Text(
                    //       "80",
                    //       style: TextStyle(
                    //           fontSize: 20, fontWeight: FontWeight.bold),
                    //     ),
                    //     SizedBox(
                    //       height: 20,
                    //     ),
                    //     Text(
                    //       "70",
                    //       style: TextStyle(
                    //           fontSize: 20, fontWeight: FontWeight.bold),
                    //     ),
                    //     SizedBox(
                    //       height: 20,
                    //     ),
                    //     Text(
                    //       "60",
                    //       style: TextStyle(
                    //           fontSize: 20, fontWeight: FontWeight.bold),
                    //     ),
                    //     SizedBox(
                    //       height: 20,
                    //     ),
                    //     Text(
                    //       "50",
                    //       style: TextStyle(
                    //           fontSize: 20, fontWeight: FontWeight.bold),
                    //     ),
                    //     SizedBox(
                    //       height: 20,
                    //     ),
                    //     Text(
                    //       "40",
                    //       style: TextStyle(
                    //           fontSize: 20, fontWeight: FontWeight.bold),
                    //     ),
                    //     SizedBox(
                    //       height: 20,
                    //     ),
                    //     Text(
                    //       "30",
                    //       style: TextStyle(
                    //           fontSize: 20, fontWeight: FontWeight.bold),
                    //     ),
                    //     SizedBox(
                    //       height: 20,
                    //     ),
                    //     Text(
                    //       "20",
                    //       style: TextStyle(
                    //           fontSize: 20, fontWeight: FontWeight.bold),
                    //     ),
                    //     SizedBox(
                    //       height: 20,
                    //     ),
                    //     Text(
                    //       "10",
                    //       style: TextStyle(
                    //           fontSize: 20, fontWeight: FontWeight.bold),
                    //     ),

                    //   ],
                    // ),
                    // ),
                    // Text("wraa")
                  ],
                ),

                Container(
                  margin: EdgeInsets.only(
                    right: 90,
                    left: 40,
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        "1",
                        style: TextStyle(fontSize: 20),
                      ),
                      Text("2",
                          style: TextStyle(
                              fontSize: 20, fontWeight: FontWeight.bold)),
                      Text("3",
                          style: TextStyle(
                              fontSize: 20, fontWeight: FontWeight.bold)),
                      Text("4",
                          style: TextStyle(
                              fontSize: 20, fontWeight: FontWeight.bold)),
                      Text("5",
                          style: TextStyle(
                              fontSize: 20, fontWeight: FontWeight.bold)),
                      Text("6",
                          style: TextStyle(
                              fontSize: 20, fontWeight: FontWeight.bold)),
                      Text("7",
                          style: TextStyle(
                              fontSize: 20, fontWeight: FontWeight.bold)),
                    ],
                  ),
                ),

                Container(
                  padding: EdgeInsets.all(20),
                  margin: EdgeInsets.only(top: 20),
                  decoration: BoxDecoration(
                      color: Colors.grey[300],
                      borderRadius: BorderRadius.circular(20)),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        "24H",
                        style: TextStyle(fontSize: 20),
                      ),
                      Container(
                          padding: EdgeInsets.only(
                              top: 5, bottom: 5, left: 20, right: 20),
                          decoration: BoxDecoration(
                              color: Colors.blue[300],
                              borderRadius: BorderRadius.circular(30)),
                          child: Text("1W", style: TextStyle(fontSize: 20))),
                      Text("1M", style: TextStyle(fontSize: 20)),
                      Text("1Y", style: TextStyle(fontSize: 20)),
                      Text("All", style: TextStyle(fontSize: 20))
                    ],
                  ),
                ),
                SizedBox(
                  height: 40,
                ),

                Row(
                  children: [
                    Text(
                      "Trading History",
                      style: TextStyle(fontSize: 30, color: Colors.white),
                    )
                  ],
                ),

                SizedBox(
                  height: 20,
                ),

                Expanded(
                  child: ListView(
                    children: [
                      Column(
                        children: [
                          TradinHistory(
                              buyOrSellIcon: "lib/images/increase.png",
                              buyOrSellBgColor: Colors.blue[300],
                              buyOrSellText: "Buy",
                              date: "21/8/2023",
                              buyPlusOrMinus: "4",
                              colorBlueOrRed: Colors.blue),
                          SizedBox(
                            height: 15,
                          ),
                          TradinHistory(
                              buyOrSellIcon: "lib/images/decrease.png",
                              buyOrSellBgColor: Colors.red[300],
                              buyOrSellText: "Sell",
                              date: "10/8/2023",
                              buyPlusOrMinus: "6",
                              colorBlueOrRed: Colors.red),
                          SizedBox(
                            height: 15,
                          ),
                          TradinHistory(
                              buyOrSellIcon: "lib/images/increase.png",
                              buyOrSellBgColor: Colors.blue[300],
                              buyOrSellText: "Buy",
                              date: "6/8/2023",
                              buyPlusOrMinus: "1",
                              colorBlueOrRed: Colors.blue),
                          SizedBox(
                            height: 15,
                          ),
                          TradinHistory(
                              buyOrSellIcon: "lib/images/decrease.png",
                              buyOrSellBgColor: Colors.red[300],
                              buyOrSellText: "Sell",
                              date: "02/8/2023",
                              buyPlusOrMinus: "3",
                              colorBlueOrRed: Colors.red),
                          SizedBox(
                            height: 15,
                          ),
                          TradinHistory(
                              buyOrSellIcon: "lib/images/increase.png",
                              buyOrSellBgColor: Colors.blue[300],
                              buyOrSellText: "Buy",
                              date: "24/7/2023",
                              buyPlusOrMinus: "0.01",
                              colorBlueOrRed: Colors.blue),
                          SizedBox(
                            height: 15,
                          ),
                          TradinHistory(
                              buyOrSellIcon: "lib/images/decrease.png",
                              buyOrSellBgColor: Colors.red[300],
                              buyOrSellText: "Sell",
                              date: "20/7/2023",
                              buyPlusOrMinus: "1",
                              colorBlueOrRed: Colors.red)
                        ],
                      ),
                    ],
                  ),
                )

                // Column(
                //   children: [
                //     Text(
                //       "40",
                //       style: TextStyle(fontSize: 20),
                //     ),
                //     SizedBox(
                //       height: 20,
                //     ),
                //     Text("40", style: TextStyle(fontSize: 20)),
                //     SizedBox(
                //       height: 20,
                //     ),
                //     Text("40", style: TextStyle(fontSize: 20)),
                //     SizedBox(
                //       height: 20,
                //     ),
                //     Text("40", style: TextStyle(fontSize: 20)),
                //     SizedBox(
                //       height: 20,
                //     ),
                //     Text("40", style: TextStyle(fontSize: 20)),
                //     SizedBox(
                //       height: 20,
                //     ),
                //     Text("40", style: TextStyle(fontSize: 20)),

                //     // Image.asset(
                //     //   "lib/images/bitcoinAnalystics.png",
                //     //   height: 200,
                //     //   width: 200,
                //     // )
                //   ],
                // )
              ],
            ),
          ),
        ),
      ),
    );
  }
}
