import 'package:flutter/material.dart';
import 'package:thirdcrypto/pages/home.dart';
import 'package:thirdcrypto/newlylaunched.dart';

import 'analytics.dart';

class AllCoins extends StatelessWidget {
  const AllCoins({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      bottomNavigationBar: BottomNavigationBar(items: [
        BottomNavigationBarItem(
            icon: GestureDetector(
              onTap: () => Navigator.push(
                  context, MaterialPageRoute(builder: (context) => Home())),
              child: Icon(
                Icons.home,
                color: Colors.grey,
              ),
            ),
            label: ""),
        BottomNavigationBarItem(
            icon: GestureDetector(
              onTap: () => Navigator.push(context,
                  MaterialPageRoute(builder: (context) => AnalyticWiddget())),
              child: Icon(
                Icons.analytics,
              ),
            ),
            label: ""),
        BottomNavigationBarItem(
            icon: Icon(
              Icons.account_balance_wallet_rounded,
              color: Colors.blue,
            ),
            label: ""),
        // BottomNavigationBarItem(icon: Icon(Icons.settings_bluetooth), label: "")
      ]),
      body: SafeArea(
        child: Container(
          decoration: BoxDecoration(
              gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [Color(0xFF3ac3cb), Color(0xFFf85187)])),
          child: Column(children: [
            Container(
              margin: EdgeInsets.all(20),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        "My Balance",
                        style: TextStyle(fontSize: 25, color: Colors.black),
                      ),
                      SizedBox(
                        height: 10,
                      ),
                      Text(
                        "\$60,0000",
                        style: TextStyle(
                            fontSize: 25,
                            fontWeight: FontWeight.bold,
                            color: Colors.black),
                      )
                    ],
                  ),
                  Image.asset(
                    "lib/images/man.png",
                    height: 80,
                    width: 80,
                  )
                ],
              ),
            ),

            /////// textfied starts here..
            Container(
              margin: EdgeInsets.all(20),
              padding: EdgeInsets.only(top: 10, bottom: 10, left: 5, right: 5),
              decoration: BoxDecoration(
                  color: Colors.grey[400],
                  borderRadius: BorderRadius.circular(12)),
              child: TextField(
                decoration: InputDecoration(
                    prefixIcon: Icon(Icons.search),
                    hintText: "Search all Coins.",
                    border: InputBorder.none),
              ),
            ),

            Container(
              margin: EdgeInsets.all(20),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    "Coins name",
                    style: TextStyle(fontSize: 25),
                  ),
                  Container(
                    child: Row(
                      children: [
                        Text(
                          "24H change",
                          style: TextStyle(fontSize: 25),
                        ),
                        Icon(
                          Icons.arrow_upward,
                          size: 40,
                        )
                      ],
                    ),
                  ),
                ],
              ),
            ),

            Expanded(
              child: ListView(
                children: [
                  Column(
                    children: [
                      NewLanuched(
                        image: "lib/images/bitcoin.png",
                        coinName: "Bitcoin",
                        coinShort: "BTC",
                        coinPrice: "511.91",
                        coinUp: "-0.08",
                        upOrDownGreenOrRedFontColor: Colors.red,
                        upOrDownIcon: Icons.arrow_drop_down,
                        colorsOfUpOrDownIconColor: Colors.red,
                      ),
                      NewLanuched(
                          image: "lib/images/ethereum.png",
                          coinName: "Ethereum",
                          coinShort: "ETH",
                          coinPrice: "206.25",
                          coinUp: "+0.72",
                          upOrDownGreenOrRedFontColor: Colors.green[900],
                          upOrDownIcon: Icons.arrow_drop_up,
                          colorsOfUpOrDownIconColor: Colors.green[900]),
                      NewLanuched(
                          image: "lib/images/tether.png",
                          coinName: "Tether USD",
                          coinShort: "USDT",
                          coinPrice: "83.41",
                          coinUp: "+0.43",
                          upOrDownGreenOrRedFontColor: Colors.green[900],
                          upOrDownIcon: Icons.arrow_drop_up,
                          colorsOfUpOrDownIconColor: Colors.green[900]),
                      NewLanuched(
                          image: "lib/images/bnb.png",
                          coinName: "BNB",
                          coinShort: "BNB",
                          coinPrice: "33.50",
                          coinUp: "+0.34",
                          upOrDownGreenOrRedFontColor: Colors.green[900],
                          upOrDownIcon: Icons.arrow_drop_up,
                          colorsOfUpOrDownIconColor: Colors.green[900]),
                      NewLanuched(
                          image: "lib/images/xrp.png",
                          coinName: "XRP",
                          coinShort: "XRP",
                          coinPrice: "27.78",
                          coinUp: "+2.90",
                          upOrDownGreenOrRedFontColor: Colors.green[900],
                          upOrDownIcon: Icons.arrow_drop_up,
                          colorsOfUpOrDownIconColor: Colors.green[900]),
                      NewLanuched(
                          image: "lib/images/USDC.png",
                          coinName: "USDC",
                          coinShort: "USDC",
                          coinPrice: "26.17",
                          coinUp: "+0.28",
                          upOrDownGreenOrRedFontColor: Colors.green[900],
                          upOrDownIcon: Icons.arrow_drop_up,
                          colorsOfUpOrDownIconColor: Colors.green[900]),
                      NewLanuched(
                          image: "lib/images/cardano.png",
                          coinName: "ADA",
                          coinShort: "XRP",
                          coinPrice: "9.48",
                          coinUp: "+1.49",
                          upOrDownGreenOrRedFontColor: Colors.green[900],
                          upOrDownIcon: Icons.arrow_drop_up,
                          colorsOfUpOrDownIconColor: Colors.green[900]),
                      NewLanuched(
                          image: "lib/images/dogecoin.png",
                          coinName: "DOGE",
                          coinShort: "XRP",
                          coinPrice: "9.02",
                          coinUp: "+1.20",
                          upOrDownGreenOrRedFontColor: Colors.green[900],
                          upOrDownIcon: Icons.arrow_drop_up,
                          colorsOfUpOrDownIconColor: Colors.green[900]),
                      NewLanuched(
                          image: "lib/images/solana.png",
                          coinName: "Solana",
                          coinShort: "SOL",
                          coinPrice: "8.98",
                          coinUp: "+1.62",
                          upOrDownGreenOrRedFontColor: Colors.green[900],
                          upOrDownIcon: Icons.arrow_drop_up,
                          colorsOfUpOrDownIconColor: Colors.green[900]),
                      NewLanuched(
                          image: "lib/images/tron.png",
                          coinName: "Thron",
                          coinShort: "TRX",
                          coinPrice: "6.68",
                          coinUp: "+1.46",
                          upOrDownGreenOrRedFontColor: Colors.green[900],
                          upOrDownIcon: Icons.arrow_drop_up,
                          colorsOfUpOrDownIconColor: Colors.green[900]),
                    ],
                  ),
                ],
              ),
            )
          ]),
        ),
      ),
    );
  }
}
