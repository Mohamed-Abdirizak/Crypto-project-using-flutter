import 'dart:collection';
import 'dart:ffi';
// import 'dart:js_util';
// import 'dart:js_util';
import 'dart:math';

// import 'package:crypto/newCoins.dart';
import 'package:flutter/material.dart';
import 'package:thirdcrypto/pages/analytics.dart';
import 'package:thirdcrypto/newCoins.dart';
import 'package:thirdcrypto/newlylaunched.dart';
import 'package:thirdcrypto/pages/allCoinsPage.dart';
// import 'package:thirdcrypto/newlylaunched.dart';

class Home extends StatelessWidget {
  const Home({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      bottomNavigationBar: BottomNavigationBar(items: [
        BottomNavigationBarItem(icon: Icon(Icons.home), label: ""),
        BottomNavigationBarItem(
            icon: GestureDetector(
              onTap: () => Navigator.push(context,
                  MaterialPageRoute(builder: (context) => AnalyticWiddget())),
              child: Icon(
                Icons.analytics,
              ),
            ),
            label: ""),
        BottomNavigationBarItem(
            icon: GestureDetector(
                onTap: () => Navigator.push(context,
                    MaterialPageRoute(builder: (context) => AllCoins())),
                child: Icon(Icons.account_balance_wallet_rounded)),
            label: ""),
        // BottomNavigationBarItem(icon: Icon(Icons.settings_bluetooth), label: "")
      ]),
      // backgroundColor: Colors.grey[600],
      body: SafeArea(
        child: Container(
          decoration: BoxDecoration(
              gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [Color(0xFF3ac3cb), Color(0xFFf85187)])),
          child: Column(
            children: [
              Container(
                margin: EdgeInsets.all(20),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          "Welcome",
                          style: TextStyle(fontSize: 25, color: Colors.black),
                        ),
                        SizedBox(
                          height: 10,
                        ),
                        Text(
                          "Fatih Jimale",
                          style: TextStyle(
                              fontSize: 25,
                              fontWeight: FontWeight.bold,
                              color: Colors.black),
                        )
                      ],
                    ),
                    Image.asset(
                      "lib/images/man.png",
                      height: 80,
                      width: 80,
                    )
                  ],
                ),
              ),

              //// second part..
              Container(
                margin: EdgeInsets.all(20),
                padding: EdgeInsets.all(20),
                decoration: BoxDecoration(
                    color: Colors.grey[400],
                    borderRadius: BorderRadius.circular(50)),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          "Balance",
                          style: TextStyle(fontSize: 20, color: Colors.black),
                        ),
                      ],
                    ),
                    SizedBox(
                      height: 10,
                    ),
                    Row(
                      children: [
                        Text(
                          "\$876,300",
                          style: TextStyle(
                              fontSize: 30,
                              fontWeight: FontWeight.bold,
                              color: Colors.black),
                        ),
                      ],
                    ),
                    SizedBox(
                      height: 30,
                    ),
                    Row(
                      /// this row starts here: contains the monthly profit, contianer(icon and 10 )
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          "Monthly Profit",
                          style: TextStyle(fontSize: 22, color: Colors.black),
                        ),
                        Container(
                          padding: EdgeInsets.only(right: 20),
                          decoration: BoxDecoration(
                              color: Colors.white30,
                              borderRadius: BorderRadius.circular(50)),
                          child: Row(
                            children: [
                              Icon(
                                Icons.arrow_drop_up,
                                size: 60,
                                color: Colors.white,
                              ),
                              Text(
                                "10%",
                                style: TextStyle(
                                    fontSize: 20, color: Colors.black),
                              )
                            ],
                          ),
                        )
                      ],
                    ),

                    /// this row ends here: contains the monthly profit, contianer(icon and 10 )

                    Text(
                      "\$43,300",
                      style: TextStyle(
                          fontSize: 30,
                          fontWeight: FontWeight.bold,
                          color: Colors.black),
                    ),
                  ],
                ),
              ),

              /// the second part ends here....

              Container(
                margin: EdgeInsets.all(20),
                child: Row(
                  children: [
                    Text(
                      "Idea for new Investors",
                      style: TextStyle(fontSize: 30, color: Colors.black),
                    )
                  ],
                ),
              ),
              /////////////////////////////// third part stars here. contains: container with bitcoin image.
              SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Container(
                  // padding: EdgeInsets.all(20),
                  margin: EdgeInsets.all(20),
                  child: Column(
                    children: [
                      Row(
                        children: [
                          NewCoins(
                              image: "lib/images/bitcoin.png",
                              coinName: "Bintcoin BTC",
                              buyerName: "Mark Zuckerber",
                              upvalue: "+6",
                              priceValue: "900,000"),

                          SizedBox(
                            width: 20,
                          ),

                          NewCoins(
                              image: "lib/images/ethereum.png",
                              coinName: "Ethereum BTH",
                              buyerName: "Donal Trump",
                              upvalue: "+9",
                              priceValue: "700,000"),
                          SizedBox(
                            width: 20,
                          ),

                          NewCoins(
                              image: "lib/images/xrp.png",
                              coinName: "XRP XRP",
                              buyerName: "Vladimir Putin",
                              upvalue: "+12",
                              priceValue: "200,000"),

                          // NewCoins(),
                          SizedBox(
                            width: 20,
                          ),
                          SizedBox(
                            width: 20,
                          ),

                          NewCoins(
                              image: "lib/images/shiba-inu.png",
                              coinName: "Shiba Inu SHIB",
                              buyerName: "Elon Musk",
                              upvalue: "+15",
                              priceValue: "350,000"),
                          SizedBox(
                            width: 20,
                          ),

                          SizedBox(
                            width: 20,
                          ),

                          NewCoins(
                              image: "lib/images/dogecoin.png",
                              coinName: "Doge Coin DOGE",
                              buyerName: "Even Spiegel",
                              upvalue: "+17",
                              priceValue: "450,000"),
                        ],
                      ),
                    ],
                  ),
                ),
              ),

              Container(
                margin: EdgeInsets.all(20),
                child: Row(
                  // crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "Newly Launched",
                      style:
                          TextStyle(fontSize: 30, fontWeight: FontWeight.bold),
                    )
                  ],
                ),
              ),

              Expanded(
                child: ListView(
                  children: [
                    Column(
                      children: [
                        NewLanuched(
                          image: "lib/images/bitcoin.png",
                          coinName: "Bitcoin",
                          coinShort: "BTC",
                          coinPrice: "511.91",
                          coinUp: "-0.08",
                          upOrDownGreenOrRedFontColor: Colors.red,
                          upOrDownIcon: Icons.arrow_drop_down,
                          colorsOfUpOrDownIconColor: Colors.red,
                        ),
                        NewLanuched(
                            image: "lib/images/ethereum.png",
                            coinName: "Ethereum",
                            coinShort: "ETH",
                            coinPrice: "206.25",
                            coinUp: "+0.72",
                            upOrDownGreenOrRedFontColor: Colors.green[900],
                            upOrDownIcon: Icons.arrow_drop_up,
                            colorsOfUpOrDownIconColor: Colors.green[900]),
                        NewLanuched(
                            image: "lib/images/tether.png",
                            coinName: "Tether USD",
                            coinShort: "USDT",
                            coinPrice: "83.41",
                            coinUp: "+0.43",
                            upOrDownGreenOrRedFontColor: Colors.green[900],
                            upOrDownIcon: Icons.arrow_drop_up,
                            colorsOfUpOrDownIconColor: Colors.green[900]),
                        NewLanuched(
                            image: "lib/images/bnb.png",
                            coinName: "BNB",
                            coinShort: "BNB",
                            coinPrice: "33.50",
                            coinUp: "+0.34",
                            upOrDownGreenOrRedFontColor: Colors.green[900],
                            upOrDownIcon: Icons.arrow_drop_up,
                            colorsOfUpOrDownIconColor: Colors.green[900]),
                        NewLanuched(
                            image: "lib/images/xrp.png",
                            coinName: "XRP",
                            coinShort: "XRP",
                            coinPrice: "27.78",
                            coinUp: "+2.90",
                            upOrDownGreenOrRedFontColor: Colors.green[900],
                            upOrDownIcon: Icons.arrow_drop_up,
                            colorsOfUpOrDownIconColor: Colors.green[900]),
                        NewLanuched(
                            image: "lib/images/USDC.png",
                            coinName: "USDC",
                            coinShort: "USDC",
                            coinPrice: "26.17",
                            coinUp: "+0.28",
                            upOrDownGreenOrRedFontColor: Colors.green[900],
                            upOrDownIcon: Icons.arrow_drop_up,
                            colorsOfUpOrDownIconColor: Colors.green[900]),
                        NewLanuched(
                            image: "lib/images/cardano.png",
                            coinName: "ADA",
                            coinShort: "XRP",
                            coinPrice: "9.48",
                            coinUp: "+1.49",
                            upOrDownGreenOrRedFontColor: Colors.green[900],
                            upOrDownIcon: Icons.arrow_drop_up,
                            colorsOfUpOrDownIconColor: Colors.green[900]),
                        NewLanuched(
                            image: "lib/images/dogecoin.png",
                            coinName: "DOGE",
                            coinShort: "XRP",
                            coinPrice: "9.02",
                            coinUp: "+1.20",
                            upOrDownGreenOrRedFontColor: Colors.green[900],
                            upOrDownIcon: Icons.arrow_drop_up,
                            colorsOfUpOrDownIconColor: Colors.green[900]),
                        NewLanuched(
                            image: "lib/images/solana.png",
                            coinName: "Solana",
                            coinShort: "SOL",
                            coinPrice: "8.98",
                            coinUp: "+1.62",
                            upOrDownGreenOrRedFontColor: Colors.green[900],
                            upOrDownIcon: Icons.arrow_drop_up,
                            colorsOfUpOrDownIconColor: Colors.green[900]),
                        NewLanuched(
                            image: "lib/images/tron.png",
                            coinName: "Thron",
                            coinShort: "TRX",
                            coinPrice: "6.68",
                            coinUp: "+1.46",
                            upOrDownGreenOrRedFontColor: Colors.green[900],
                            upOrDownIcon: Icons.arrow_drop_up,
                            colorsOfUpOrDownIconColor: Colors.green[900]),
                      ],
                    ),
                  ],
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
