import 'dart:ffi';

import 'package:flutter/material.dart';

class NewCoins extends StatelessWidget {
  final image;
  final String coinName;
  final String buyerName;
  final String upvalue;
  final String priceValue;

  const NewCoins(
      {super.key,
      required this.image,
      required this.coinName,
      required this.buyerName,
      required this.upvalue,
      required this.priceValue});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 300,
      // height: 200,
      // margin: EdgeInsets.all(20),
      padding: EdgeInsets.all(20),
      decoration: BoxDecoration(
          color: Colors.grey[400], borderRadius: BorderRadius.circular(12)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Image.asset(
                this.image,
                height: 50,
                width: 50,
              ),
              SizedBox(
                width: 20,
              ),
              Text(
                this.coinName,
                style: TextStyle(
                    fontSize: 25,
                    color: Colors.black,
                    fontWeight: FontWeight.bold),
              )
            ],
          ),
          SizedBox(
            height: 20,
          ),
          Row(
            children: [
              Text(
                this.buyerName,
                style: TextStyle(fontSize: 25, color: Colors.black),
              )
            ],
          ),
          SizedBox(
            height: 10,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                "Price",
                style: TextStyle(
                    fontSize: 20,
                    color: Colors.black,
                    fontWeight: FontWeight.bold),
              ),
              Container(
                // width: 50,
                padding: EdgeInsets.only(right: 20, top: 5, bottom: 5),
                decoration: BoxDecoration(
                    color: Colors.white54,
                    borderRadius: BorderRadius.circular(12)),
                child: Row(
                  children: [
                    Icon(
                      Icons.arrow_drop_up,
                      size: 30,
                      color: Colors.black,
                    ),
                    Text(
                      this.upvalue,
                      style: TextStyle(fontSize: 20),
                    )
                  ],
                ),
              )
            ],
          ),
          Text(
            "\$" + this.priceValue,
            style: TextStyle(
                fontSize: 25, color: Colors.black, fontWeight: FontWeight.bold),
          )
        ],
      ),
    );
  }
}
